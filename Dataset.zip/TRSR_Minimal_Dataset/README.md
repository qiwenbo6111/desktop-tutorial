# Three-River Source Region manuscript minimal dataset

Prepared 6 November 2026. Study year: 2020. This is an upload-ready processed-data archive for the manuscript, not a new experiment or a public repository deposit. No original source files were overwritten.

## Contents and interpretation

- `data/nine_scale`: the nine original scale-specific analysis CSVs, preserved byte for byte. The three response names are CS_HQ, CS_WC and HQ_WC. Configuration labels are 30, 100, 250, 500, 1000, 1500, 2000, 2500 and 3000 m; they refer to historical source-product configurations, not nine controlled changes of a single input resolution.
- `data/point_mappings` and `data/rf`: actual projected point coordinates, original per-scale IDs, a 3610-point common registry, explicit training/test fold membership, and training-only clipping statistics. Rows are joined by ID and coordinates, never by an unverified CSV row number.
- `data/spatial`: 27 historical TOS fields aggregated to the frozen 3 km grid, 27 corresponding aggregated service fields, the 40006-cell common mask, Queen adjacency and row-standardized weights. See `metadata/spatial_grid.json` and `metadata/reference_crs.prj` for geometry. Values outside the common mask are not used in Moran calculations.
- `data/sem_syntax`: the exact M0 and M2 structures for 54 fits. `results/sem` includes all fit indices, parameter estimates, preprocessing and covariance matrices. M0 is the original latent model; M2 is the fixed WaterVeg model. Ordinary ML was used in this comparison, not robust MLR. Six M2 fits pass the saved joint criteria; improved fit alone does not establish causality.
- `results/rf`: all 292410 out-of-fold predictions for 81 scale/pair/validation tasks; 405 fold results; pooled metrics and held-out permutation importance. `data/rf/permutation_checkpoints` includes the 135 full-nine-variable, seed-zero, 100 km / 15 km buffer checkpoints used for the final spatial-importance analysis. Unused sensitivity models and alternative response chains are excluded.
- `data/pdp`: 243 saved curves with 24300 predictor-grid values, original OOB importance and crossing tables. `PDP_zero_crossings_original.csv` is an unchanged historical record, including its original conclusion column. That column is not an endorsed ecological interpretation. Use `PDP_zero_crossings.csv`, which removes that column. Centering is yhat minus the arithmetic mean of yhat on each stored curve grid. A centered zero crossing is not an independently validated ecological threshold.
- `data/manuscript_tables`: the two numbered manuscript tables as reported, plus Table 2 in a long numerical format. These are reported table values, not a claim that native pixel counts can be recomputed from the coarse archive.
- `figures`: reported native-map renderings for Figures 1 and 3-5, and final numerical-result figures 6-15. Figure 2 is a conceptual workflow and has no separate numerical dataset. Map renderings are images, not georeferenced analytical rasters. PDFs of Figures 9-15 contain the original raster plots with updated text labels; their curves are not newly vectorized.

## Response identity and reproducibility boundary

The retained original CSV responses were previously matched numerically to normalized service contrasts, with C=CS/298.4, Q=HQ, W=WC/configuration-specific denominator, CS_HQ=Q-C, CS_WC=C-W and HQ_WC=Q-W. The package preserves the stored values; it does not relabel them as independently verified Spearman coefficients. Moran describes spatial clustering of these retained fields. The manuscript's historical Spearman terminology cannot be authenticated by renaming these columns. No fixed-30-km Spearman or SPEAR5 replacement data are mixed into this archive.

This archive allows independent checking of the reported statistical quantities and inspection of displayed map products. It does **not** reproduce native-resolution Figures 3-5 from full rasters, derive Table 2 native-area percentages from the 3 km fields, or rerun the entire InVEST chain. The 54 excluded native TOS/service raster sources and their sizes are listed in `metadata/excluded_native_rasters.csv`; those sources remain with the authors. The full input-raster, original-run-parameter and native-map provenance chain is not certified by this minimal archive. Third-party input data remain attributable to the providers listed in the reported Table 1. External provider availability or licences were not newly checked for this packaging task.

## Run the checks

Use Python 3.11 with NumPy, pandas and SciPy. Unzip the archive and run commands from its root. The verifier reads inputs and writes only under `reproduced/`.

```sh
python code/verify_results.py
python code/verify_results.py --full-permutations
python code/plot_results.py
```

The default verifier checks SHA256 file integrity, joins all RF responses to original CSV values, recomputes 81 pooled metric sets, verifies the 54-fit decision counts, tests all stored PDP centerings, recomputes 27 observed Moran statistics, and reconstructs permutation importance plus its 1999-replicate 90 km spatial-block bootstrap intervals. The second command additionally recalculates all 999 Moran permutations (seed 20261102; two-sided p centered on -1/(n-1), minimum p=0.001). No model training is performed by either verification command. Figure 6 includes the restored 30 m CS-WC Moran value 0.7579960866423012.

`plot_results.py` illustrates how to plot the frozen numerical results. Formatting can differ from the final layout; crossing strings in the historical table are rounded. Final publication renderings are supplied separately under `figures/`. It does not rerun the historical R random forest or generate new PDP predictions.

## Optional full model refits

The portable copies of the historical Python fitting algorithms use only package-relative input paths and write under `reproduced/`. Parameters, preprocessing and fitted-model definitions are retained. These optional scripts were syntax-checked during packaging; the models were not retrained for this archive.

```sh
python code/refit_rf.py --pilot
python code/refit_rf.py
python code/refit_sem.py
```

`refit_rf.py` retains the historical validation algorithm and its small existing no-winsor sensitivity, including 500 trees, max_features=3, min_samples_leaf=5, seed 20261029 and per-fold seed offsets. Predictor clipping uses only training data; responses are not clipped. Spatial blocks are assigned by (floor(x/B)+2*floor(y/B)) mod 5, B=50000 or 100000 m; training points within 15 km of test points are excluded. These folds test spatial separation on an interspersed block lattice, not leave-one-contiguous-region-out extrapolation. Use scikit-learn 1.2.2 for the historical refits; later versions can change numerical predictions. This Python implementation is not an exact recreation of the original R forest/OOB/PDP implementation. The saved original R PDP/OOB outputs remain separate.

`refit_sem.py` requires semopy 2.3.11 and preserves the ordinary-ML comparison, the original full-table clipping/standardization, unconstrained residual-variance diagnostic and the M2 covariance extension. Core M0/M2 observed-variable sets and degrees of freedom differ. Numerical optimizer differences across platforms are possible. Original model-fit outputs are frozen under `results/sem`.

## Metadata and checksums

`metadata/variable_dictionary.csv` describes input variables without inventing missing source-product units. `metadata/field_inventory.csv` lists each CSV column. `metadata/array_inventory.csv` lists shapes and dtypes in NPZ files. `metadata/figure_table_crosswalk.csv` links manuscript items to data. `metadata/file_manifest.csv` records all distributed files except itself, with byte size and SHA256. `metadata/copied_file_provenance.json` records source basenames and checksums without exposing personal absolute workspace paths. Analysis code and documentation are in English.

No new open-source or third-party-data licence is asserted in this archive. Cite the associated article and the original data providers. Article details, public accession identifiers and a repository DOI should only be added when actually assigned.
