"""Verify the frozen manuscript analysis data without fitting any model."""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import argparse,json,hashlib
import numpy as np,pandas as pd
from scipy import sparse

ROOT=Path(__file__).resolve().parents[1]
def read(p):return pd.read_csv(ROOT/p,float_precision='round_trip')
def main(full=False):
    checks={};manifest=ROOT/'metadata/file_manifest.csv'
    if manifest.exists():
        for a in pd.read_csv(manifest).itertuples():assert hashlib.sha256((ROOT/a.file).read_bytes()).hexdigest()==a.SHA256,a.file
        checks['file_hashes_verified']=len(pd.read_csv(manifest))
    reg=read('data/rf/common_3610_point_registry.csv');assert len(reg)==3610 and reg.point_key.is_unique
    oof=read('results/rf/RF_all_OOF_predictions.csv');saved=read('results/rf/RF_spatial_CV_81groups_long.csv');rows=[]
    for (s,p,sc),a in oof.groupby(['scale_m','pair','scenario'],sort=False):
        assert len(a)==3610 and a.point_key.is_unique
        source=read(f'data/nine_scale/scale_{s}m.csv').set_index('ID');order=reg.set_index('point_key').loc[a.point_key,f'ID_{s}m'];expected=source.loc[order,p].to_numpy();y=a.observed.to_numpy();assert np.max(abs(y-expected))<1e-12
        e=a.predicted.to_numpy()-y;m=dict(R2=1-np.sum(e*e)/np.sum((y-y.mean())**2),RMSE=np.sqrt(np.mean(e*e)),MAE=np.mean(abs(e)),Bias=e.mean())
        b=saved[saved.scale_m.eq(s)&saved.pair.eq(p)&saved.scenario.eq(sc)].iloc[0]
        assert max(abs(m[k]-b[k]) for k in m)<1e-12
        rows.append(dict(scale_m=s,pair=p,scenario=sc,**m))
    checks.update(RF_groups=len(rows),OOF_rows=len(oof));assert len(rows)==81 and len(oof)==292410
    summary=pd.DataFrame(rows).groupby('scenario')[['R2','RMSE','MAE']].mean();checks['RF_macro_means']=summary.to_dict('index')
    f=read('results/sem/01_SEM_original_vs_candidate_fit.csv');assert len(f)==54
    checks['SEM_M0_improper']=int((~f[f.model.eq('M0')].admissible).sum());checks['SEM_M2_eligible']=int(f[f.model.eq('M2')].eligible.sum());assert checks['SEM_M0_improper']==24 and checks['SEM_M2_eligible']==6
    pdp=read('data/pdp/PDP_curves.csv');mu=pdp.groupby(['scale','outcome','variable']).yhat.transform('mean');err=np.max(abs(pdp.yhat_centered-(pdp.yhat-mu)));assert err<1e-12;checks['PDP_curves']=pdp.groupby(['scale','outcome','variable']).ngroups;checks['PDP_centering_max_error']=float(err)
    z=np.load(ROOT/'data/spatial/TOS_27_common3km.npz');mask=z['common_mask'];assert mask.sum()==40006;w=sparse.load_npz(ROOT/'data/spatial/queen_row_standardized_weights.npz');keys=[k for k in z if k.startswith('D_')];assert len(keys)==27
    x=np.column_stack([z[k][mask] for k in keys]);x-=x.mean(0);den=np.sum(x*x,0);obs=(len(x)/float(w.sum()))*np.sum(x*(w@x),0)/den
    table=read('results/moran/Morans_I_27.csv');lut={f'D_{int(a.source_m)}_{a.pair}':a.Morans_I for a in table.itertuples()};error=max(abs(v-lut[k]) for k,v in zip(keys,obs));assert error<1e-12;checks['Moran_max_error']=float(error);checks['Moran_30m_CS_WC']=float(obs[keys.index('D_30_CS_WC')])
    if full:
        rng=np.random.default_rng(20261102);draws=np.empty((999,27));EI=-1/(len(x)-1)
        for b in range(999):
            a=x[rng.permutation(len(x))];draws[b]=(len(x)/float(w.sum()))*np.sum(a*(w@a),0)/den
        p=(np.sum(abs(draws-EI)>=abs(obs-EI),axis=0)+1)/1000;assert np.all(p==.001);checks['Moran_permutations_recalculated']=999
    # Reconstruct spatial importance and its saved 90 km block-bootstrap intervals.
    im=read('results/rf/RF_spatial_OOF_permutation_importance.csv');xy=reg[['x','y']].to_numpy();_,inv=np.unique(np.floor(xy/90000),axis=0,return_inverse=True);K=inv.max()+1
    draws=np.random.default_rng(20261101).integers(0,K,(1999,K));counts=np.array([np.bincount(a,minlength=K) for a in draws]);denom=counts@np.bincount(inv);maximum=0.
    for s in sorted(oof.scale_m.unique()):
        for pair in ['CS_HQ','CS_WC','HQ_WC']:
            loss=np.full((12,3,3610),np.nan);y=np.full(3610,np.nan)
            for fold in range(5):
                cp=ROOT/f'data/rf/permutation_checkpoints/{s}_{pair}_spatial_100km_buffer15km_{fold}_full9_fixed3_seed0.npz';a=np.load(cp);te=a['test'];loss[:,:,te]=a['permutation_loss_delta'];y[te]=a['observed']
            assert np.isfinite(loss).all();variance=np.var(y)
            for j,item in enumerate(a['permutation_items']):
                point=loss[j].mean(0);val=point.mean()/variance;boot=(counts@np.bincount(inv,weights=point))/denom/variance;lo,hi=np.quantile(boot,[.025,.975]);t=im[im.scale_m.eq(s)&im.pair.eq(pair)&im.variable.eq(item)].iloc[0];maximum=max(maximum,abs(val-t.delta_R2),abs(lo-t.CI_low),abs(hi-t.CI_high))
    assert maximum<1e-11;checks['importance_and_CI_max_error']=float(maximum)
    out=ROOT/'reproduced';out.mkdir(exist_ok=True);(out/'verification.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--full-permutations',action='store_true');args=p.parse_args();main(args.full_permutations)
