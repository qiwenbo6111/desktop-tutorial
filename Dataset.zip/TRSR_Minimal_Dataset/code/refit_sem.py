import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']: os.environ[k]='1'
from pathlib import Path
import sys,json,hashlib,itertools,warnings,time
import numpy as np,pandas as pd
from scipy.stats import norm
ROOT=Path(__file__).resolve().parents[1]
O=ROOT/'reproduced/sem'; O.mkdir(parents=True,exist_ok=True)
W=ROOT; E=ROOT/'data/nine_scale'; P=ROOT/'data/sem_syntax'
from semopy import Model
SCALES=[30,100,250,500,1000,1500,2000,2500,3000]; PAIRS=['CS_HQ','CS_WC','HQ_WC']
X=['DEM','Slop','pre','tem','ept','gdp','pop','lud','NDVI']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(d,n):pd.DataFrame(d).to_csv(O/n,index=False,encoding='utf-8-sig',float_format='%.17g')
def clean(raw):
 d=raw.loc[:,~raw.isna().all()].copy();d=d[[c for c in d if not pd.api.types.is_numeric_dtype(d[c]) or d[c].std()>1e-10]]
 for c in d.select_dtypes(include=np.number): d[c]=d[c].clip(d[c].mean()-3*d[c].std(),d[c].mean()+3*d[c].std())
 d=d.loc[d.isna().mean(axis=1)<.3];z=d.copy()
 for c in z.select_dtypes(include=np.number):z[c]=(z[c]-z[c].mean())/z[c].std()
 return d,z
def metrics(S,C,n,k):
 p=len(S);df=p*(p+1)//2-k;ld=np.linalg.slogdet(S)[1];lc=np.linalg.slogdet(C)[1]
 chi=n*(lc+np.trace(np.linalg.solve(C,S))-ld-p);base=n*(np.log(np.diag(S)).sum()-ld);bdf=p*(p-1)//2
 ll=-n/2*(p*np.log(2*np.pi)+lc+np.trace(np.linalg.solve(C,S)))
 r=(S-C)/np.sqrt(np.outer(np.diag(S),np.diag(S)))
 return dict(df=df,n_cov_parameters=k,n_observed=p,chi2=chi,CFI=1-(chi-df)/(base-bdf),TLI=(base/bdf-chi/df)/(base/bdf-1),RMSEA=np.sqrt(max((chi/df-1)/n,0)),SRMR=np.sqrt(np.mean(r[np.triu_indices(p)]**2)),loglik=ll,AIC=-2*ll+2*(k+p),BIC=-2*ll+np.log(n)*(k+p),baseline_chi2=base)
def broad(r,prefix=''):
 return r[prefix+'CFI']>=.9 and r[prefix+'TLI']>=.9 and r[prefix+'RMSEA']<=.08 and r[prefix+'SRMR']<=.08
def main():
 start=time.time();manifest=[];fits=[];params=[];covs={};prep=[]
 paths=[E/f'scale_{s}m.csv' for s in SCALES]+list(P.glob('syntax_*.txt'))
 for p in paths:manifest.append(dict(path=str(p),bytes=p.stat().st_size,mtime_ns=p.stat().st_mtime_ns,sha256=sha(p)))
 save(manifest,'input_manifest.csv')
 for s in SCALES:
  raw=pd.read_csv(E/f'scale_{s}m.csv');d,z=clean(raw);assert not z[X+PAIRS].isna().any().any()
  for c in X+PAIRS:prep.append(dict(source_m=s,variable=c,n=len(z),raw_mean=raw[c].mean(),raw_sd=raw[c].std(),clipped_count=int((raw.loc[d.index,c]!=d[c]).sum()),clipped_mean=d[c].mean(),clipped_sd=d[c].std()))
  for y in PAIRS:
   allnames=X+[y];Sfull=np.cov(z[allnames],rowvar=False,bias=True)
   for label in ['M0','M2']:
    syn=(P/f'syntax_{label}_{s}_{y}.txt').read_text(encoding='utf8')
    (O/f'syntax_{label}_{s}_{y}.txt').write_text(syn,encoding='utf8');m=Model(syn)
    if label=='M0':m.first_manifs.update({'ThermalEnergy':'DEM','Vegetation':'pre'})
    # Same unconstrained observed-residual ML semantics for both models.
    for p in m.parameters.values():
     if p.active and any(loc.matrix is m.mx_theta and loc.indices[0]==loc.indices[1] for loc in p.locations):p.bound=(None,None)
    with warnings.catch_warnings(record=True) as ws:
     warnings.simplefilter('always');res=m.fit(z[allnames],obj='MLW',solver='SLSQP',options={'maxiter':5000,'ftol':1e-11});par=m.inspect(std_est=True)
     fim=m.calc_fim()
    names=m.vars['observed'];S=m.mx_cov;C=m.calc_sigma()[0];k=sum(p.active for p in m.parameters.values());core=metrics(S,C,len(z),k)
    if label=='M2':
     extra=[v for v in allnames if v not in names];cn=names+extra;SF=np.cov(z[cn],rowvar=False,bias=True);q=len(names)
     B=np.linalg.solve(SF[:q,:q],SF[:q,q:]).T;psi=SF[q:,q:]-B@SF[:q,q:]
     CF=np.block([[C,C@B.T],[B@C,psi+B@C@B.T]])
     full=metrics(SF,CF,len(z),k+len(extra)*q+len(extra)*(len(extra)+1)//2)
    else:cn=names;SF=S;CF=C;full=core
    var=par[par.op.eq('~~')&par.lval.eq(par.rval)];neg=var.Estimate.lt(-1e-8).sum();boundary=var.Estimate.abs().le(1e-7).sum()
    loads=par[par.op.eq('~')&par.rval.isin(m.vars['latent'])];over=int(loads['Est. Std'].abs().gt(1+1e-6).sum())
    se=pd.to_numeric(par['Std. Err'],errors='coerce');active=se.notna();seok=bool(np.isfinite(se[active]).all() and se[active].gt(0).all())
    eig=np.linalg.eigvalsh(fim);rank=int(np.linalg.matrix_rank(fim));fimeig=float(eig.min());eigC=float(np.linalg.eigvalsh(CF).min())
    admiss=bool(res.success and not neg and not boundary and not over and eigC>1e-8 and rank==k and seok)
    row=dict(source_m=s,pair=y,model=label,n=len(z),converged=bool(res.success),negative_variances=int(neg),boundary_variances=int(boundary),loading_abs_over1=over,implied_cov_min_eigenvalue=eigC,FIM_rank=rank,FIM_dimension=k,FIM_min_eigenvalue=fimeig,finite_positive_SE=seok,admissible=admiss,**full,**{'core_'+a:b for a,b in core.items()},warnings=' | '.join(str(w.message) for w in ws),estimator='ordinary_ML',common_observed_set=True,nuisance_extension=label=='M2',AIC_BIC_include_10_mean_parameters=True)
    row['core_broad_fit']=broad(row,'core_');row['common_broad_fit']=broad(row);row['eligible']=bool(admiss and row['core_broad_fit'] and row['common_broad_fit']);fits.append(row)
    key=f'{s}_{y}_{label}';covs[key+'_sample']=SF;covs[key+'_implied']=CF;covs[key+'_names']=np.array(cn);covs[key+'_core_sample']=S;covs[key+'_core_implied']=C
    for r in par.to_dict('records'):
     se1=pd.to_numeric(r['Std. Err'],errors='coerce');std=r['Est. Std'];ratio=std/r['Estimate'] if abs(r['Estimate'])>1e-14 else np.nan
     # Delta-method CI uses full derivative of standardization, not scaled raw SE; computed below.
     params.append(dict(source_m=s,pair=y,model=label,**r,raw_CI_low=r['Estimate']-1.95996398454*se1,raw_CI_high=r['Estimate']+1.95996398454*se1,parameter_valid=admiss,standardized_CI_low=np.nan,standardized_CI_high=np.nan))
    # Numerically differentiate all standardized estimates; includes estimated variance uncertainty.
    theta=m.param_vals.copy();j=np.zeros((len(par),len(theta)));h=1e-5
    for t in range(len(theta)):
     plus=theta.copy();minus=theta.copy();plus[t]+=h;minus[t]-=h
     m.param_vals=plus;m.update_matrices(plus);a=m.inspect(std_est=True,information=None)['Est. Std'].to_numpy(float)
     m.param_vals=minus;m.update_matrices(minus);b=m.inspect(std_est=True,information=None)['Est. Std'].to_numpy(float)
     j[:,t]=(a-b)/(2*h)
    m.param_vals=theta;m.update_matrices(theta);vc=np.linalg.pinv(fim);sd=np.sqrt(np.maximum(np.einsum('ij,jk,ik->i',j,vc,j),0))
    for r,se2 in zip(params[-len(par):],sd):r.update(standardized_SE=float(se2),standardized_CI_low=r['Est. Std']-1.95996398454*se2,standardized_CI_high=r['Est. Std']+1.95996398454*se2,CI_method='ordinary_ML_expected_information_delta_method_not_spatial')
    print(s,y,label,'admissible',admiss,'coreRMSEA',core['RMSEA'],'eligible',row['eligible'],flush=True)
    save(fits,'01_SEM_original_vs_candidate_fit.csv');save(params,'02_SEM_all_parameters.csv')
 np.savez_compressed(O/'fitted_covariances.npz',**covs);save(prep,'preprocessing.csv')
 save([r for r in params if r['op']=='~'],'02_SEM_path_comparison.csv')
 assert all(sha(Path(r['path']))==r['sha256'] for r in manifest)
 (O/'run_metadata.json').write_text(json.dumps(dict(status='54_fits_finished',elapsed_seconds=time.time()-start,n_fits=len(fits),all_input_hashes_unchanged=True,bootstrap_run=False,estimator='ordinary_ML_not_robust_MLR',M2_nuisance_note='unrestricted conditional Gaussian of tem,ept,gdp,pop given six WaterVeg core observables; no new ecological paths; same core df and chi-square',selection_requires_both_core_and_common_fit=True),indent=2),encoding='utf8')
if __name__=='__main__':main()
