"""Plot frozen numerical data; no model fitting or new PDP predictions."""
from pathlib import Path
import pandas as pd,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
R=Path(__file__).resolve().parents[1];O=R/'reproduced/figures';O.mkdir(parents=True,exist_ok=True)
S=[30,100,250,500,1000,1500,2000,2500,3000];L=['30','100','250','500','1k','1.5k','2k','2.5k','3k'];P=['CS_HQ','CS_WC','HQ_WC']
m=pd.read_csv(R/'results/moran/Morans_I_27.csv');fig,ax=plt.subplots(figsize=(8,4.5))
for p in P:ax.plot(range(9),m[m.pair.eq(p)].set_index('source_m').loc[S].Morans_I,'o-',label=p.replace('_','-'))
ax.set_xticks(range(9),L);ax.set(xlabel='Source configuration (m)',ylabel="Global Moran's I");ax.legend();fig.tight_layout();fig.savefig(O/'Figure_6.pdf');plt.close(fig)
f=pd.read_csv(R/'results/sem/01_SEM_original_vs_candidate_fit.csv');fig,axs=plt.subplots(3,4,figsize=(9,7),sharex=True)
for i,p in enumerate(P):
    for j,(v,t) in enumerate([('CFI',.9),('TLI',.9),('RMSEA',.08),('SRMR',.08)]):
        ax=axs[i,j]
        for model,c,mark in [('M0','#D55E00','o'),('M2','#0072B2','s')]:
            a=f[f.pair.eq(p)&f.model.eq(model)].set_index('source_m').loc[S];ax.plot(range(9),a['core_'+v],marker=mark,color=c,ms=3);bad=~a.admissible;ax.scatter(np.arange(9)[bad],a.loc[bad,'core_'+v],marker='x',color='black',s=20)
        ax.axhline(t,color='grey',ls='--',lw=.6);ax.set_xticks(range(9),L,rotation=60)
        if i==0:ax.set_title(v)
        if j==0:ax.set_ylabel(p)
fig.subplots_adjust(bottom=.15,hspace=.2,wspace=.4);fig.legend(handles=[Line2D([],[],color='#D55E00',marker='o',label='M0'),Line2D([],[],color='#0072B2',marker='s',label='M2'),Line2D([],[],color='black',marker='x',ls='None',label='Improper'),Line2D([],[],color='grey',ls='--',label='Reference')],loc='lower center',ncol=4);fig.savefig(O/'Figure_7.pdf');plt.close(fig)
f=pd.read_csv(R/'results/rf/RF_spatial_CV_81groups_long.csv');fig,axs=plt.subplots(1,3,figsize=(11,3.6))
for ax,p in zip(axs,P):
    for sc in ['random5','spatial50km','spatial100km']:
        a=f[f.pair.eq(p)&f.scenario.eq(sc)].set_index('scale_m').loc[S];ax.plot(range(9),a.R2,'o-',label=sc,ms=3)
    ax.set_xticks(range(9),L,rotation=60);ax.set(title=p,ylabel='OOF R squared');ax.legend(fontsize=7)
fig.tight_layout();fig.savefig(O/'Figure_8.pdf');plt.close(fig)
pdp=pd.read_csv(R/'data/pdp/PDP_curves.csv');cross=pd.read_csv(R/'data/pdp/PDP_zero_crossings.csv')
for n,(var,p) in enumerate([(v,p) for v in ['pre','lud'] for p in P],10):
    fig,axs=plt.subplots(3,3,figsize=(9,8))
    for s,ax in zip(S,axs.flat):
        a=pdp[pdp.scale.eq(s)&pdp.outcome.eq(p)&pdp.variable.eq(var)].sort_values('value');ax.plot(a.value,a.yhat_centered,color='#2166AC');ax.axhline(0,color='black',lw=.7)
        b=cross[cross.scale.eq(s)&cross.outcome.eq(p)&cross.variable.eq(var)].iloc[0]
        if bool(b.has_zero_crossing):
            for value in str(b.all_thresholds).split(';'):ax.axvline(float(value),color='red',ls='--',lw=.7)
        ax.set(title=f'{s} m',xlabel='Precipitation (source units)' if var=='pre' else 'LUD index',ylabel='Centered partial dependence')
    fig.tight_layout();fig.savefig(O/f'Figure_{n}.pdf');plt.close(fig)
print(O)
