from pathlib import Path
import argparse,os,time,json,hashlib,platform,datetime,sys
os.environ.setdefault('OMP_NUM_THREADS','1')
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
import numpy as np,pandas as pd,scipy,sklearn,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.spatial import cKDTree
from scipy import sparse
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import KFold
from sklearn.metrics import r2_score,mean_squared_error,mean_absolute_error

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'data'
AUDIT=ROOT/'data/point_mappings'
OUT=ROOT/'reproduced/rf'
OUT.mkdir(parents=True,exist_ok=True)
SCALES=[30,100,250,500,1000,1500,2000,2500,3000]
TARGETS=['CS_WC','CS_HQ','HQ_WC']
DRIVERS=['DEM','Slop','pre','tem','ept','gdp','pop','lud','NDVI']
MAP_NAMES={30:'yw30m',100:'yw100m',250:'yw250m',500:'yw500m',1000:'yw1000m',1500:'yw1500m',2000:'yw2000mshp',2500:'yw2500m',3000:'yw3000m2'}
SEED=20261029
LIMITATION='HISTORICAL_ORIGINAL_CSV_RESPONSE_NO_INDEPENDENT_SERVICE_VALIDATION'
PARAMS=dict(n_estimators=500,max_features=3,min_samples_leaf=5,min_samples_split=2,bootstrap=True,max_samples=None,n_jobs=4,criterion='squared_error')

def log(s):
 print(datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(timespec='seconds'),s,flush=True)
 with (OUT/'run.log').open('a',encoding='utf-8') as f:f.write(str(s)+'\n')

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()

def load_data():
 tables={};manifest=[]
 for scale in SCALES:
  csv=SRC/'nine_scale'/f'scale_{scale}m.csv';mp=AUDIT/f'agent_tos_points_csv_mapping_{MAP_NAMES[scale]}.csv'
  d=pd.read_csv(csv);m=pd.read_csv(mp)
  assert d.ID.is_unique and m.csv_ID.is_unique
  assert set(d.ID)==set(m.csv_ID),f'mapping coverage {scale}'
  d=d.merge(m[['csv_ID','x','y','source_row','source_FID_yw']],left_on='ID',right_on='csv_ID',validate='one_to_one')
  assert len(d)==len(m) and not d[['x','y']].isna().any().any()
  assert np.isfinite(d[DRIVERS+TARGETS+['x','y']].to_numpy(float)).all()
  d['point_key']=[f'{x:.3f}|{y:.3f}' for x,y in zip(d.x,d.y)]
  assert d.point_key.is_unique
  tables[scale]=d.set_index('point_key',drop=False)
  manifest +=[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in [csv,mp]]
 common=sorted(set.intersection(*(set(d.index) for d in tables.values())))
 assert len(common)==3610,f'common point count {len(common)}'
 tables={s:d.loc[common].reset_index(drop=True) for s,d in tables.items()}
 coords=tables[1000][['x','y']].to_numpy(float)
 for scale,d in tables.items():assert np.max(np.abs(d[['x','y']].to_numpy(float)-coords))<0.001
 pd.DataFrame(manifest).to_csv(OUT/'input_manifest_sha256.csv',index=False,encoding='utf-8-sig')
 return tables,coords

def make_splits(coords):
 n=len(coords);result={};allrows=[];meta=[]
 for block_m in [50000,100000]:
  bx=np.floor(coords[:,0]/block_m).astype(int);by=np.floor(coords[:,1]/block_m).astype(int)
  fold=(bx+2*by)%5
  scenario=f'spatial_{block_m//1000}km_buffer15km'
  splits=[]
  for f in range(5):
   test=np.flatnonzero(fold==f);candidate=np.flatnonzero(fold!=f)
   distance=cKDTree(coords[test]).query(coords[candidate],k=1)[0]
   train=candidate[distance>15000.0+1e-6]
   assert len(test)>300 and len(train)>800 and not set(train)&set(test)
   mind=float(cKDTree(coords[test]).query(coords[train],k=1)[0].min())
   assert mind>15000
   assert not set(zip(bx[train],by[train]))&set(zip(bx[test],by[test]))
   splits.append((train,test))
   meta.append(dict(scenario=scenario,fold=f,n_train=len(train),n_test=len(test),n_buffer_removed=len(candidate)-len(train),minimum_train_test_m=mind,test_blocks=len(set(zip(bx[test],by[test])))))
  result[scenario]=splits
  allrows.extend(dict(scenario=scenario,index=i,x=coords[i,0],y=coords[i,1],fold=int(fold[i]),block_x=int(bx[i]),block_y=int(by[i])) for i in range(n))
 random_splits=list(KFold(n_splits=5,shuffle=True,random_state=SEED).split(np.arange(n)))
 scenario='random_5fold'
 rf=np.full(n,-1,dtype=int)
 for f,(tr,te) in enumerate(random_splits):
  rf[te]=f
  meta.append(dict(scenario=scenario,fold=f,n_train=len(tr),n_test=len(te),n_buffer_removed=0,minimum_train_test_m=float(cKDTree(coords[te]).query(coords[tr],k=1)[0].min()),test_blocks=np.nan))
 result[scenario]=random_splits
 allrows.extend(dict(scenario=scenario,index=i,x=coords[i,0],y=coords[i,1],fold=int(rf[i]),block_x=np.nan,block_y=np.nan) for i in range(n))
 pd.DataFrame(allrows).to_csv(OUT/'fold_assignments.csv',index=False,encoding='utf-8-sig')
 pd.DataFrame(meta).to_csv(OUT/'split_diagnostics.csv',index=False,encoding='utf-8-sig')
 return result,pd.DataFrame(meta)

def metrics(y,p):
 return dict(r2=float(r2_score(y,p)),rmse=float(mean_squared_error(y,p,squared=False)),mae=float(mean_absolute_error(y,p)),bias=float(np.mean(p-y)))

def fit_predict(X,y,train,test,seed,winsor=True):
 xx=X.copy()
 if winsor:
  mu=np.mean(xx[train],axis=0);sd=np.std(xx[train],axis=0,ddof=1)
  lo=mu-3*sd;hi=mu+3*sd
  xx=np.minimum(np.maximum(xx,lo),hi)
 model=RandomForestRegressor(random_state=seed,**PARAMS)
 model.fit(xx[train],y[train])
 pred=model.predict(xx[test])
 return pred,float(y[train].mean()),model.feature_importances_

def weights(coords):
 pairs=cKDTree(coords).query_pairs(r=15000,output_type='ndarray')
 assert len(pairs)>0
 row=np.r_[pairs[:,0],pairs[:,1]];col=np.r_[pairs[:,1],pairs[:,0]]
 w=sparse.csr_matrix((np.ones(len(row)),(row,col)),shape=(len(coords),len(coords)))
 return w

def moran(resid,w,seed,n_perm=199):
 z=resid-np.mean(resid);den=float(z@z);s0=float(w.sum());n=len(z)
 if den==0:return dict(moran_i=np.nan,moran_expected=-1/(n-1),moran_perm_p=np.nan,moran_perm_n=n_perm)
 fun=lambda zz:float(n/s0*(zz@(w@zz))/den)
 obs=fun(z);rng=np.random.default_rng(seed);exp=-1/(n-1)
 sims=np.array([fun(rng.permutation(z)) for _ in range(n_perm)])
 p=float((1+np.sum(np.abs(sims-exp)>=abs(obs-exp)))/(n_perm+1))
 return dict(moran_i=obs,moran_expected=exp,moran_perm_p=p,moran_perm_n=n_perm)

def saveplot_folds(coords,splitdict):
 fig,axes=plt.subplots(1,3,figsize=(15,5),constrained_layout=True)
 for ax,(scenario,splits) in zip(axes,splitdict.items()):
  f=np.full(len(coords),-1)
  for fold,(_,test) in enumerate(splits):f[test]=fold
  ax.scatter(coords[:,0]/1000,coords[:,1]/1000,c=f,cmap='tab10',s=6,vmin=0,vmax=9)
  ax.set(title=scenario,xlabel='Projected easting (km)',ylabel='Projected northing (km)');ax.set_aspect('equal')
 fig.suptitle('OLD-RESPONSE DIAGNOSTIC: common 3610 sample points')
 fig.savefig(OUT/'fold_maps.png',dpi=180);plt.close(fig)

def main(pilot=False):
 start=time.time();tables,coords=load_data();splitdict,splitmeta=make_splits(coords);saveplot_folds(coords,splitdict)
 log('DATA_READY common_points=3610 '+splitmeta.to_json(orient='records'))
 if pilot:
  s=1000;target='CS_WC';X=tables[s][DRIVERS].to_numpy(float);y=tables[s][target].to_numpy(float)
  t=time.time();tr,te=splitdict['spatial_50km_buffer15km'][0]
  p,b,imp=fit_predict(X,y,tr,te,SEED)
  result={'scale':s,'target':target,'scenario':'spatial_50km_buffer15km','fold':0,'seconds':time.time()-t,'n_train':len(tr),'n_test':len(te),'metrics':metrics(y[te],p),'params':PARAMS,'limitation':LIMITATION}
  (OUT/'pilot.json').write_text(json.dumps(result,indent=2),encoding='utf-8');log('PILOT '+json.dumps(result));return
 summaries=[];foldmetrics=[];importance=[];w=weights(coords)
 for s in SCALES:
  d=tables[s];X=d[DRIVERS].to_numpy(float)
  for target_i,target in enumerate(TARGETS):
   y=d[target].to_numpy(float)
   for scen_i,(scenario,splits) in enumerate(splitdict.items()):
    taskstart=time.time();pred=np.full(len(y),np.nan);base=np.full(len(y),np.nan);folds=np.full(len(y),-1,dtype=int)
    for f,(tr,te) in enumerate(splits):
     seed=SEED+s*10+target_i*100000+f
     p,b,imp=fit_predict(X,y,tr,te,seed,winsor=True)
     pred[te]=p;base[te]=b;folds[te]=f
     m=metrics(y[te],p);bm=metrics(y[te],np.repeat(b,len(te)))
     foldmetrics.append(dict(scale_m=s,outcome=target,scenario=scenario,fold=f,n_train=len(tr),n_test=len(te),**m,**{'baseline_'+k:v for k,v in bm.items()},status=LIMITATION))
     importance.extend(dict(scale_m=s,outcome=target,scenario=scenario,fold=f,variable=v,impurity_importance=float(value)) for v,value in zip(DRIVERS,imp))
    assert np.isfinite(pred).all() and np.isfinite(base).all() and np.all(folds>=0)
    m=metrics(y,pred);bm=metrics(y,base);mi=moran(pred-y,w,SEED+s+target_i*10000+scen_i*100000)
    summaries.append(dict(scale_m=s,outcome=target,scenario=scenario,n=len(y),**m,**{'baseline_'+k:v for k,v in bm.items()},**mi,elapsed_seconds=time.time()-taskstart,status=LIMITATION))
    predtable=pd.DataFrame({'point_key':d.point_key,'original_csv_ID':d.ID,'source_FID_yw':d.source_FID_yw,'x':coords[:,0],'y':coords[:,1],'fold':folds,'observed_old_response':y,'oof_prediction':pred,'oof_training_mean_baseline':base,'residual_prediction_minus_observed':pred-y,'status':LIMITATION})
    predtable.to_csv(OUT/f'oof_{s}m_{target}_{scenario}.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(summaries).to_csv(OUT/'oof_metrics.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(foldmetrics).to_csv(OUT/'per_fold_metrics.csv',index=False,encoding='utf-8-sig')
    log(f'FINISHED {s}m {target} {scenario} R2={m["r2"]:.4f} RMSE={m["rmse"]:.5f} Moran={mi["moran_i"]:.3f} secs={time.time()-taskstart:.1f}')
 pd.DataFrame(importance).to_csv(OUT/'fold_impurity_importance.csv',index=False,encoding='utf-8-sig')
 # Only one prespecified scale for a no-winsor sensitivity.
 sens=[];s=1000;d=tables[s];X=d[DRIVERS].to_numpy(float)
 for target_i,target in enumerate(TARGETS):
  y=d[target].to_numpy(float)
  for scenario in ['spatial_50km_buffer15km','random_5fold']:
   pred=np.full(len(y),np.nan)
   for f,(tr,te) in enumerate(splitdict[scenario]):pred[te]=fit_predict(X,y,tr,te,SEED+s*10+target_i*100000+f,winsor=False)[0]
   sens.append(dict(scale_m=s,outcome=target,scenario=scenario,preprocessing='no_winsor',**metrics(y,pred),status=LIMITATION))
 pd.DataFrame(sens).to_csv(OUT/'no_winsor_1000m_sensitivity.csv',index=False,encoding='utf-8-sig')
 summary=pd.DataFrame(summaries)
 fig,axes=plt.subplots(1,3,figsize=(14,4.5),constrained_layout=True)
 colors={'spatial_50km_buffer15km':'#2166ac','spatial_100km_buffer15km':'#b2182b','random_5fold':'#238b45'}
 for ax,target in zip(axes,TARGETS):
  for scenario,g in summary[summary.outcome==target].groupby('scenario'):
   ax.plot(g.scale_m,g.r2,'o-',label=scenario,color=colors[scenario],ms=4)
  ax.axhline(0,c='0.4',lw=.8);ax.set(title=target,xlabel='Scale (m)',ylabel='OOF R²');ax.grid(alpha=.2)
 axes[-1].legend(fontsize=7);fig.suptitle('OLD-RESPONSE DIAGNOSTIC - not corrected-service validation');fig.savefig(OUT/'oof_r2_by_scale.png',dpi=190);plt.close(fig)
 manifest=pd.read_csv(OUT/'input_manifest_sha256.csv');assert all(sha(Path(r.path))==r.sha256 for r in manifest.itertuples()),'Input changed during run'
 meta=dict(status='complete',limitation=LIMITATION,python=sys.version,python_executable=sys.executable,numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,sklearn=sklearn.__version__,matplotlib=matplotlib.__version__,platform=platform.platform(),seed=SEED,params=PARAMS,main_models=27,main_scenarios=3,main_fold_fits=405,extra_sensitivity_fits=30,common_n=3610,moran_weights='symmetric binary distance<=15km; no self weights; two-sided permutation199; diagnostic of old-response OOF residuals',started_utc=datetime.datetime.fromtimestamp(start,datetime.timezone.utc).isoformat(),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.time()-start,input_hashes_unchanged=True)
 (OUT/'rf_results.json').write_text(json.dumps({'run':meta,'metrics':summaries,'no_winsor_sensitivity':sens},ensure_ascii=False,indent=2),encoding='utf-8')
 log('ALL_DONE '+json.dumps(meta))

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--pilot',action='store_true');args=parser.parse_args();main(args.pilot)
